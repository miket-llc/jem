<template>
  <div>
    <h1>Joystick Remapper</h1>
    <button @click="findDevices">Find Devices</button>
    <button @click="connectToVirtualDevice">Connect to Virtual Device</button>
    <button @click="writeOutput">Write Output</button>
    <div v-if="devices.length">
      <h2>Devices</h2>
      <ul>
        <li v-for="device in devices" :key="device.id">{{ device.name }}</li>
      </ul>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
//import type { Device } from '../preload/types'

const devices = ref<Device[]>([])

const findDevices = async () => {
  try {
    const foundDevices = await window.electron.findDevices()
    devices.value = foundDevices
  } catch (error) {
    console.error('Error finding devices:', error)
  }
}

const connectToVirtualDevice = async () => {
  const deviceId = 'mock-device-1' // Replace with actual device ID
  await window.electron.connectToVirtualDevice(deviceId)
}

const writeOutput = async () => {
  const deviceId = 'mock-device-1' // Replace with actual device ID
  const output = {} // Replace with actual output data
  await window.electron.writeOutput(deviceId, output)
}

onMounted(() => {
  window.electron.receiveInput('mock-device-1').then((input) => {
    console.log('Input received:', input)
  })
})
</script>
